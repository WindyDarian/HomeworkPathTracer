Render Sample:

Ship model from my assignment for 3D Modeling class

Triangle count for mesh: Around 6k
Monte Carlo path tracer (hw05) 
Multiple importance sampling 
Indirect lighting
BVH Tree with surface area heuristic
Resolution: 1024x576
Sample per pixel: 256
Tracing depth: min 3 + Russian Roulette termination;
Render Time: 62 min



Blooper:
got tangent direction wrong for HW04